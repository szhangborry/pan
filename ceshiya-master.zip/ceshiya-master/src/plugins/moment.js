import moment from 'moment';
import 'moment/locale/zh-cn';

moment.locale('zh-cn');

/**
 * 时间日期处理
 * @author yupi
 */
export default moment;
