export const RECOMMEND_TAG = '推荐';

export const LIKE_TAG = '收藏';

/**
 * 补充首页标签
 * @author https://yuyuanweb.feishu.cn/wiki/Abldw5WkjidySxkKxU2cQdAtnah yupi
 */
export const EXTRA_TAG_LIST = [RECOMMEND_TAG, LIKE_TAG];
